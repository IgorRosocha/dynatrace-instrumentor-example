import Foundation
import XCTest

final class DynatraceExample2Tests: XCTestCase {
    func test_twoPlusTwo_isFour() {
        XCTAssertEqual(2+2, 4)
    }
}